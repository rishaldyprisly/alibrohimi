
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>Checkout example for Bootstrap</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="assets/bootstrap/form-validation.css" rel="stylesheet">
  </head>

  <body class="bg-light">

    <div class="container bg-info">
      <div class="py-5 text-center">
        <img class="d-block mx-auto mb-4" src="assets/bootstrap/ma-aly.png" alt="" width="72" height="72">
        <h2>Ma'had Aly Al ibrohimi</h2>
        <p class="lead">Angkatan 1 Periode (2018-2019)</p>
        <p>Jl. P.P Al Ibrohimi 01/40 Manyarejo Manyar Gresik 61151 (081 359 876 114 / 089 359 876 114 / 089 657 866)</p>
      </div>

      <h4 class="col-md-12">Form Pendaftaran</h4>
      <form class="needs-validation " novalidate>
        <div class="row">            
          <div class="col-sm">
            <div class="list-group-item">
              <div class="input-group">
                <h5>II. Identitas Pribadi</h5>&nbsp;
                <p class="text-danger"> (sesuai ijazah)</p> 
              </div>

              <div>
                <h6 class="text-muted">Nama Lengkap</h6>
                <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                <div class="invalid-feedback">
                  mohon diisi
                </div>
              </div>
              <div>
                <h6 class="text-muted">Tempat dan tanggal lahir</h6>
                <input type="text" class="form-control form-control-sm" id="ttl" placeholder="Contoh cara ngisi : Gresik 20 januari 1992 " required>
                <div class="invalid-feedback">
                  mohon diisi
                </div>
              </div>
              <div>
                <h6 class="text-muted">Jenis Kelamin</h6>
                <select class="custom-select d-block w-100" id="gender" required>
                  <option value="">pilih</option>
                  <option>Laki - laki</option>
                  <option>Perempuan</option>
                </select>
                <div class="invalid-feedback">
                  mohon dipilih 
                </div>
              </div>
              <div>
                <h6 class="text-muted">Alamat</h6>
                <input type="text" class="form-control form-control-sm" id="alamat" placeholder="" required>
                <div class="invalid-feedback">
                  Mohon isi alamat Anda.
                </div>
              </div>
            </div>
          </div>  

          <div class="col-sm">
            <div class="list-group-item">
              <div class="input-group">
                <h5>Nama Orang Tua</h5>
              </div>

              <div>
                <h6 class="text-muted">Nama Ayah</h6>
                <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                <div class="invalid-feedback">
                  mohon diisi
                </div>
              </div>
              <div>
                <h6 class="text-muted">Nama Ibu</h6>
                <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                <div class="invalid-feedback">
                  mohon diisi
                </div>
              </div>
              <div>
                <h6 class="text-muted">Pekerjaan Ayah</h6>
                <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                <div class="invalid-feedback">
                  mohon diisi
                </div>
              </div>
              <div>
                <h6 class="text-muted">Pekerjaan Ibu</h6>
                <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                <div class="invalid-feedback">
                  mohon diisi
                </div>
              </div>
              <div>
                <h6 class="text-muted">No Telp/HP</h6>
                <input type="number" class="form-control form-control-sm" id="telp" placeholder="" required>
                <div class="invalid-feedback">
                  mohon diisi
                </div>
              </div>
            </div>              
          </div>            
        </div>

        <div class="row">
          <div class="col-sm">
            <div class="list-group-item">

              <div class="input-group">
                <h5>III. Riwayat Pesantren Asal</h5> 
              </div>

              <div class="row">
                <div class="col-sm">
                  <h6 class="text-muted">Nama Pesantren</h6>
                  <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                  <div class="invalid-feedback">
                    mohon diisi
                  </div>
                </div>              
                <div class="col-sm">
                  <h6 class="text-muted">Alamat</h6>
                  <input type="text" class="form-control form-control-sm" id="alamat" placeholder="" required>
                  <div class="invalid-feedback">
                    Mohon isi alamat Anda.
                  </div>
                </div>
                <div class="col-sm">
                  <h6 class="text-muted">No Telp</h6>
                  <input type="number" class="form-control form-control-sm" id="telp" placeholder="" required>
                  <div class="invalid-feedback">
                    mohon diisi
                  </div>
                </div>                
              </div>                               
            </div>  
          </div>
        </div>

        <div class="row">
          <div class="col-sm">
            <div class="list-group-item">

              <div class="input-group">
                <h5>IV. Pemberi Rekomendasi</h5> &nbsp;
                <p class="text-danger font-weight-bold"> jika tidak ada kosongkan</p> 
              </div>

              <div class="row">
                <div class="col-sm">
                  <h6 class="text-muted">Nama</h6>
                  <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                  <div class="invalid-feedback">
                    mohon diisi
                  </div>
                </div>              
                <div class="col-sm">
                  <h6 class="text-muted">Jabatan</h6>
                  <input type="text" class="form-control form-control-sm" id="alamat" placeholder="" required>
                  <div class="invalid-feedback">
                    Mohon isi alamat Anda.
                  </div>
                </div>
                <div class="col-sm">
                  <h6 class="text-muted">Alamat</h6>
                  <input type="text" class="form-control form-control-sm" id="telp" placeholder="" required>
                  <div class="invalid-feedback">
                    mohon diisi
                  </div>
                </div>
                <div class="col-sm">
                  <h6 class="text-muted">Hubungan</h6>
                  <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                  <div class="invalid-feedback">
                    mohon diisi
                  </div>
                </div>
              </div>  

            </div>  
          </div>
        </div>

        <div class="row">
          <div class="col-sm">
            <div class="list-group-item">
              <div class="input-group">
                <h5>V. Riwayat Pendidikan Diniyah</h5> &nbsp;
              </div>

              <table class="table table-striped table-sm">
                <thead>
                  <tr  class="text-center">
                    <th>Riwayat Pendidikan Diniyah</th>
                    <th>Nama Lembaga</th>
                    <th>Tahun Masuk</th>
                    <th>Tahun Lulus</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>a. MI / MDS*</td>
                    <td>
                      <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                      <div class="invalid-feedback">
                        mohon diisi
                      </div>
                    </td>
                    <td >
                      <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                      <div class="invalid-feedback">
                        mohon diisi
                      </div>
                    </td>
                    <td >
                      <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                      <div class="invalid-feedback">
                        mohon diisi
                      </div>
                    </td>                                      
                  </tr>
                  <tr>
                    <td>b. MTs / MDW*</td>
                    <td>
                      <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                      <div class="invalid-feedback">
                        mohon diisi
                      </div>
                    </td>
                    <td>
                      <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                      <div class="invalid-feedback">
                        mohon diisi
                      </div>
                    </td>
                    <td>
                      <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                      <div class="invalid-feedback">
                        mohon diisi
                      </div>
                    </td>                                      
                  </tr>
                  <tr>
                    <td>c. MA / MDU*</td>
                    <td>
                      <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                      <div class="invalid-feedback">
                        mohon diisi
                      </div>
                    </td>
                    <td>
                      <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                      <div class="invalid-feedback">
                        mohon diisi
                      </div>
                    </td>
                    <td>
                      <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                      <div class="invalid-feedback">
                        mohon diisi
                      </div>
                    </td>                                      
                  </tr>
                   <tr>
                    <td>d. Lainnya</td>
                    <td>
                      <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                      <div class="invalid-feedback">
                        mohon diisi
                      </div>
                    </td>
                    <td>
                      <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                      <div class="invalid-feedback">
                        mohon diisi
                      </div>
                    </td>
                    <td>
                      <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                      <div class="invalid-feedback">
                        mohon diisi
                      </div>
                    </td>                                      
                  </tr>
                </tbody>
              </table>

            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-sm">
            <div class="list-group-item">
              <div class="input-group">
                <h5>VI. Riwayat Pendidikan Umum</h5> &nbsp;
              </div>

              <table class="table table-striped table-sm">
                <thead>
                  <tr  class="text-center">
                    <th>Riwayat Pendidikan Diniyah</th>
                    <th>Nama Lembaga</th>
                    <th>Tahun Masuk</th>
                    <th>Tahun Lulus</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>a. SD / MI*</td>
                    <td>
                      <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                      <div class="invalid-feedback">
                        mohon diisi
                      </div>
                    </td>
                    <td >
                      <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                      <div class="invalid-feedback">
                        mohon diisi
                      </div>
                    </td>
                    <td >
                      <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                      <div class="invalid-feedback">
                        mohon diisi
                      </div>
                    </td>                                      
                  </tr>
                  <tr>
                    <td>b. SLTP / MTs*</td>
                    <td>
                      <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                      <div class="invalid-feedback">
                        mohon diisi
                      </div>
                    </td>
                    <td>
                      <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                      <div class="invalid-feedback">
                        mohon diisi
                      </div>
                    </td>
                    <td>
                      <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                      <div class="invalid-feedback">
                        mohon diisi
                      </div>
                    </td>                                      
                  </tr>
                  <tr>
                    <td>c. SMA / MA*</td>
                    <td>
                      <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                      <div class="invalid-feedback">
                        mohon diisi
                      </div>
                    </td>
                    <td>
                      <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                      <div class="invalid-feedback">
                        mohon diisi
                      </div>
                    </td>
                    <td>
                      <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                      <div class="invalid-feedback">
                        mohon diisi
                      </div>
                    </td>                                      
                  </tr>
                  <tr>
                    <td>d. Perguruan Tinggi</td>
                    <td>
                      <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                      <div class="invalid-feedback">
                        mohon diisi
                      </div>
                    </td>
                    <td>
                      <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                      <div class="invalid-feedback">
                        mohon diisi
                      </div>
                    </td>
                    <td>
                      <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                      <div class="invalid-feedback">
                        mohon diisi
                      </div>
                    </td>                                      
                  </tr>
                </tbody>
              </table>

            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-sm">
            <div class="list-group-item">
              
              <div class="input-group">
                <h5>VII. Alasan Masuk Ma'had Aly Marhalah Tsaniyah</h5> &nbsp;
              </div>
              <textarea class="form-control" rows="3" id="comment"></textarea>
            </div>  
          </div>  
        </div>  

        <div class="row">
          <div class="col-sm">
            <div class="list-group-item">
              
                <div class="input-group">
                  <h5>VIII. Karya ilmiyah Yang pernah ditulis</h5> &nbsp;
                </div>

                <table class="table table-striped table-sm">
                  <thead>
                    <tr>
                    <th>Judul</th>
                    <th>Tahun</th>
                    <th>Lembaga Publikasi</th>
                  </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                          <div class="invalid-feedback">
                            mohon diisi
                          </div>
                      </td>
                      <td>
                        <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                          <div class="invalid-feedback">
                            mohon diisi
                          </div>
                      </td>
                      <td>
                        <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                          <div class="invalid-feedback">
                            mohon diisi
                          </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                          <div class="invalid-feedback">
                            mohon diisi
                          </div>
                      </td>
                      <td>
                        <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                          <div class="invalid-feedback">
                            mohon diisi
                          </div>
                      </td>
                      <td>
                        <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                          <div class="invalid-feedback">
                            mohon diisi
                          </div>
                      </td>
                    </tr>
                  </tbody>  
                </table>

            </div>  
          </div>  
        </div>

        <div class="row">
          <div class="col-sm">
            <div class="list-group-item">
              
                <div class="input-group">
                  <h5>IX. Kitab fikih klasik yang pernah dikaji</h5> &nbsp;
                </div>

                <table class="table table-striped table-sm">
                  <thead>
                    <tr>
                    <th>Nama kitab</th>
                    <th>Nama Mualim</th>
                    <th>Tahun</th>
                  </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                          <div class="invalid-feedback">
                            mohon diisi
                          </div>
                      </td>
                      <td>
                        <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                          <div class="invalid-feedback">
                            mohon diisi
                          </div>
                      </td>
                      <td>
                        <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                          <div class="invalid-feedback">
                            mohon diisi
                          </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                          <div class="invalid-feedback">
                            mohon diisi
                          </div>
                      </td>
                      <td>
                        <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                          <div class="invalid-feedback">
                            mohon diisi
                          </div>
                      </td>
                      <td>
                        <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                          <div class="invalid-feedback">
                            mohon diisi
                          </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                          <div class="invalid-feedback">
                            mohon diisi
                          </div>
                      </td>
                      <td>
                        <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                          <div class="invalid-feedback">
                            mohon diisi
                          </div>
                      </td>
                      <td>
                        <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                          <div class="invalid-feedback">
                            mohon diisi
                          </div>
                      </td>
                    </tr>
                  </tbody>  
                </table>

            </div>  
          </div>  
        </div>

        <div class="row">
          <div class="col-sm">
            <div class="list-group-item">
              
                <div class="input-group">
                  <h5>IX. Kitab Ushul fikih yang pernah dikaji</h5> &nbsp;
                </div>

                <table class="table table-striped table-sm">
                  <thead> 
                  <tr>
                    <th>Nama Kitab</th>
                    <th>Nama Mualim</th>
                    <th>Tahun</th>
                  </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                          <div class="invalid-feedback">
                            mohon diisi
                          </div>
                      </td>
                      <td>
                        <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                          <div class="invalid-feedback">
                            mohon diisi
                          </div>
                      </td>
                      <td>
                        <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                          <div class="invalid-feedback">
                            mohon diisi
                          </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                          <div class="invalid-feedback">
                            mohon diisi
                          </div>
                      </td>
                      <td>
                        <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                          <div class="invalid-feedback">
                            mohon diisi
                          </div>
                      </td>
                      <td>
                        <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                          <div class="invalid-feedback">
                            mohon diisi
                          </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                          <div class="invalid-feedback">
                            mohon diisi
                          </div>
                      </td>
                      <td>
                        <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                          <div class="invalid-feedback">
                            mohon diisi
                          </div>
                      </td>
                      <td>
                        <input type="text" class="form-control form-control-sm" id="nama-lengkap" placeholder="" required>
                          <div class="invalid-feedback">
                            mohon diisi
                          </div>
                      </td>
                    </tr>
                  </tbody>  
                </table>

            </div>  
          </div>  
        </div>

        <div class="row">
          <div class="col-sm">
            <div class="list-group-item">
              helloworld
            </div>
          </div>          
        </div>

        <div class="row d-flex justify-content-center">
          <div class="col-3">
            <div class="my-3 ">
              <button class="btn btn-warning btn-lg btn-block" type="submit">Simpan</button>
            </div>
          </div>          
        </div>
        
            

            <!-- <div class="row">     
              <footer class="my-5 pt-5 text-muted text-center text-small">
                <p class="mb-1">&copy; 2017-2018 Company Name</p>        
              </footer>
            </div>  -->      
      </form>
    </div>  

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="../../assets/js/vendor/popper.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>
    <script src="../../assets/js/vendor/holder.min.js"></script>
    <script>
      // Example starter JavaScript for disabling form submissions if there are invalid fields
      (function() {
        'use strict';

        window.addEventListener('load', function() {
          // Fetch all the forms we want to apply custom Bootstrap validation styles to
          var forms = document.getElementsByClassName('needs-validation');

          // Loop over them and prevent submission
          var validation = Array.prototype.filter.call(forms, function(form) {
            form.addEventListener('submit', function(event) {
              if (form.checkValidity() === false) {
                event.preventDefault();
                event.stopPropagation();
              }
              form.classList.add('was-validated');
            }, false);
          });
        }, false);
      })();
    </script>
  </body>
</html>
