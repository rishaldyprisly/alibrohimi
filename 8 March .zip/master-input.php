
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>Beranda Administrator</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="assets/bootstrap/dashboard.css" rel="stylesheet">
  </head>

  <body>
    <nav class="navbar navbar-dark fixed-top bg-success flex-md-nowrap p-0 shadow">
      <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="http://localhost/alibrohimi/login-keuangan.php">Al-Ibrohimi</a>
    </nav>

    <div class="container-fluid">
      <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link active" href="http://localhost/alibrohimi/beranda-administrator-keuangan.php">
                  <span data-feather="home"></span>
                  Dashboard <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="http://localhost/alibrohimi/master-akun.php">
                  <span data-feather="file"></span>
                  Master akun
                </a>
              </li>
              
              <li class="nav-item">
                <a class="nav-link" href="http://localhost/alibrohimi/.php">
                  <span data-feather="layers"></span>
                  Master Data

                </a>
                <ul class="">
                  <li> 
                    <a class="" href="http://localhost/alibrohimi/master-input.php">
                      Master Input
                    </a>
                  </li>
                  <li> 
                    <a class="" href="http://localhost/alibrohimi/data-siswa.php">
                      Data Siswa
                    </a>
                  </li>
                  <li> 
                    <a class="" href="http://localhost/alibrohimi/kenaikan-kelas.php">
                      Kenaikan Kelas
                    </a>
                  </li>
                  <li> 
                    <a class="" href="http://localhost/alibrohimi/kelulusan.php">
                      Kelulusan
                    </a>
                  </li>
                </ul>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="http://localhost/alibrohimi/tagihan.php">
                  <span data-feather="calendar"></span>
                  Tagihan
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link " href="http://localhost/alibrohimi/pengaturan-administrator.php">
                  <span data-feather="cloud"></span>
                  Pengaturan
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link " href="http://localhost/alibrohimi/pemeliharaan-administrator.php">
                  <span data-feather="database"></span>
                  Pemeliharaan
                </a>
              </li>
            </ul>            
          </div>
        </nav>

        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h6 class="h6">Master Input</h6>
          </div>

<div>
  <button type="button" class="btn btn-primary">Tambah Lembaga</button>
  <button type="button" class="btn btn-secondary">Tambah Tahun masuk</button>
  <button type="button" class="btn btn-success">Tambah Kelas Sekolah</button>
  <button type="button" class="btn btn-danger">Tambah Kelas Madin</button>
  <button type="button" class="btn btn-warning">Tambah Kelas Pondok</button>
  
</div><p></p><p></p>

<!-- 

          <p>berisi input lembaga</p>
          <p>input kelas sekolah</p>
          <p>input kelas madin</p>
          <p>input kelas pondok</p>
          <p>input tahun </p>
          <p>input bulan (karna pembayaran sekolah biasanya dimulai dari juli 2018 - juni 2019)</p>
  

 -->
 <div class="alert alert-primary" role="alert">
  A simple primary alert—check it out!
</div>

          <div class="row">
            
            <div class="col-4 ">
              <h6>Jenis Lembaga</h6> 
              <div class="table-responsive alert alert-danger" role="alert">
                <table class="table table-striped table-sm">
                  <thead>
                    <tr>
                      <th>Kode</th>
                      <th>Nama Lembaga</th>
                      <th>Aksi</th>

                    </tr>
                  </thead>
                  <tbody>                
                    <tr>
                      <td>MA</td>
                      <td>Madrasah Aliyah</td>
                      <td></td>
                    </tr>  
                    <tr>
                      <td>MTs</td>
                      <td>Madrasah Tsanawiyah</td>
                      <td></td>
                    </tr>
                               
                  </tbody>
                </table>
              </div>
            <!-- </div> -->
            <p></p>
            <!-- <div class="col-2"> -->
              <h6>Tahun Masuk</h6> 
              <div class="table-responsive alert alert-success"  role="alert">
                <table class="table table-striped table-sm">
                  <thead>
                    <tr>
                      <th>Tahun Masuk</th>
                      <th>Aksi</th>

                    </tr>
                  </thead>
                  <tbody>                
                    <tr>
                      <td>2018-2019</td>
                      <td></td>                    
                    </tr>  
                    <tr>
                      <td>2018-2019</td>
                      <td></td>
                    </tr>  
                    <tr>
                      <td>2019-2020</td>  
                      <td></td>
                    </tr>           
                  </tbody>
                </table>
              </div>
            <!-- </div> -->
            <p></p>
            <!-- <div class="col-2"> -->
              <h6>Jenis Pondok</h6> 
              <div class="table-responsive alert alert-warning" role="alert">
                <table class="table table-striped table-sm">
                  <thead>
                    <tr>
                      <th>Kode</th>
                      <th>Nama Lembaga</th>
                      <th>Aksi</th>

                    </tr>
                  </thead>
                  <tbody>                
                    <tr>
                      <td>QK</td>
                      <td>Qiroatil Kutub</td>
                      <td></td>
                    </tr>  
                    <tr>
                      <td>TQ</td>
                      <td>Tahfidzul Quran</td>
                      <td></td>
                    </tr>             
                  </tbody>
                </table>
              </div>
            </div>
            <div class="col-4">
              <h6>Jenis Sekolah</h6> 
              <div class="table-responsive">
                <table class="table table-striped table-sm">
                  <thead>
                    <tr>
                      <th>Kelas</th>
                      <th>Ruang</th>
                      <th>Lembaga</th>
                      <th>Aksi</th>

                    </tr>
                  </thead>
                  <tbody>                
                    <tr> <td>7</td><td>A</td><td>MTs</td><td></td> </tr>
                    <tr> <td>7</td><td>B</td><td>MTs</td><td></td> </tr>
                    <tr> <td>7</td><td>C</td><td>MTs</td><td></td> </tr>
                    <tr> <td>7</td><td>D</td><td>MTs</td><td></td> </tr>
                    <tr> <td>7</td><td>E</td><td>MTs</td><td></td> </tr>
                    <tr> <td>7</td><td>F</td><td>MTs</td><td></td> </tr>
                    <tr> <td>7</td><td>G</td><td>MTs</td><td></td> </tr>
                    <tr> <td>8</td><td>A</td><td>MTs</td><td></td> </tr>
                    <tr> <td>8</td><td>B</td><td>MTs</td><td></td> </tr>
                    <tr> <td>8</td><td>C</td><td>MTs</td><td></td> </tr>
                    <tr> <td>8</td><td>D</td><td>MTs</td><td></td> </tr>
                    <tr> <td>8</td><td>E</td><td>MTs</td><td></td> </tr>
                    <tr> <td>8</td><td>F</td><td>MTs</td><td></td> </tr>
                    <tr> <td>8</td><td>G</td><td>MTs</td><td></td> </tr>
                    <tr> <td>9</td><td>A</td><td>MTs</td><td></td> </tr>
                    <tr> <td>9</td><td>B</td><td>MTs</td><td></td> </tr>
                    <tr> <td>9</td><td>C</td><td>MTs</td><td></td> </tr>
                    <tr> <td>9</td><td>D</td><td>MTs</td><td></td> </tr>
                    <tr> <td>9</td><td>E</td><td>MTs</td><td></td> </tr>
                    <tr> <td>9</td><td>F</td><td>MTs</td><td></td> </tr>
                    <tr> <td>9</td><td>G</td><td>MTs</td><td></td> </tr>
                    <tr> <td>10</td><td>MIPA-1</td><td>MA</td><td></td> </tr>
                    <tr> <td>10</td><td>MIPA-2</td><td>MA</td><td></td> </tr>
                    <tr> <td>10</td><td>IIS</td><td>MA</td><td></td> </tr>
                    <tr> <td>10</td><td>BHS</td><td>MA</td><td></td> </tr>
                    <tr> <td>10</td><td>IIS-2</td><td>MA</td><td></td> </tr>
                    <tr> <td>11</td><td>MIPA-1</td><td>MA</td><td></td> </tr>
                    <tr> <td>11</td><td>MIPA-2</td><td>MA</td><td></td> </tr>
                    <tr> <td>11</td><td>IIS</td><td>MA</td><td></td> </tr>
                    <tr> <td>11</td><td>BHS</td><td>MA</td><td></td> </tr>
                    <tr> <td>11</td><td>IIS-2</td><td>MA</td><td></td> </tr>
                    <tr> <td>12</td><td>MIPA-1</td><td>MA</td><td></td> </tr>
                    <tr> <td>12</td><td>MIPA-2</td><td>MA</td><td></td> </tr>
                    <tr> <td>12</td><td>IIS</td><td>MA</td><td></td> </tr>
                    <tr> <td>12</td><td>BHS</td><td>MA</td><td></td> </tr>
                    <tr> <td>12</td><td>IIS-2</td><td>MA</td><td></td> </tr>
                    
                  </tbody>
                </table>
              </div>
            </div>
            <div class="col-4">
              <h6>Jenis Madin</h6> 
              <div class="table-responsive">
                <table class="table table-striped table-sm">
                  <thead>
                    <tr>
                      <th>Kelas</th>
                      <th>Nama Madin</th>
                      <th>Aksi</th>

                    </tr>
                  </thead>
                  <tbody>                
                    <tr>
                      <td>1-Awl</td>
                      <td>Awwaliyah</td>
                      <td></td>
                    </tr>  
                    <tr>
                      <td>2-Awl</td>
                      <td>Awwaliyah</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>3-Awl</td>
                      <td>Awwaliyah</td>
                      <td></td>
                    </tr>
                     <tr>
                      <td>1-Wst</td>
                      <td>Washatiyah</td>
                      <td></td>
                    </tr>  
                    <tr>
                      <td>2-Wst</td>
                      <td>Washatiyah</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>3-Wst</td>
                      <td>Washatiyah</td>
                      <td></td>
                    </tr>             
                  </tbody>
                </table>
              </div>
            </div>
            
            
           
          </div> 

        </main>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="../../assets/js/vendor/popper.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>

    <!-- Icons -->
    <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
    <script>
      feather.replace()
    </script>

    <!-- Graphs -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js"></script>
    <script>
      var ctx = document.getElementById("myChart");
      var myChart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
          datasets: [{
            data: [15339, 21345, 18483, 24003, 23489, 24092, 12034],
            lineTension: 0,
            backgroundColor: 'transparent',
            borderColor: '#007bff',
            borderWidth: 4,
            pointBackgroundColor: '#007bff'
          }]
        },
        options: {
          scales: {
            yAxes: [{
              ticks: {
                beginAtZero: false
              }
            }]
          },
          legend: {
            display: false,
          }
        }
      });
    </script>
  </body>
</html>
