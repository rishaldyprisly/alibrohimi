
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>Beranda Administrator</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="assets/bootstrap/dashboard.css" rel="stylesheet">
  </head>

  <body>
    <nav class="navbar navbar-dark fixed-top bg-success flex-md-nowrap p-0 shadow">
      <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="http://localhost/alibrohimi/login-keuangan.php">Al-Ibrohimi</a>
    </nav>

    <div class="container-fluid">
      <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link active" href="http://localhost/alibrohimi/beranda-administrator-keuangan.php">
                  <span data-feather="home"></span>
                  Dashboard <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="http://localhost/alibrohimi/master-akun.php">
                  <span data-feather="file"></span>
                  Master akun
                </a>
              </li>
              
              <li class="nav-item">
                <a class="nav-link" href="http://localhost/alibrohimi/.php">
                  <span data-feather="layers"></span>
                  Master Data

                </a>
                <ul class="">
                  <li> 
                    <a class="" href="http://localhost/alibrohimi/master-input.php">
                      Master Input
                    </a>
                  </li>
                  <li> 
                    <a class="" href="http://localhost/alibrohimi/data-siswa.php">
                      Data Siswa
                    </a>
                  </li>
                  <li> 
                    <a class="" href="http://localhost/alibrohimi/kenaikan-kelas.php">
                      Kenaikan Kelas
                    </a>
                  </li>
                  <li> 
                    <a class="" href="http://localhost/alibrohimi/kelulusan.php">
                      Kelulusan
                    </a>
                  </li>
                </ul>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="http://localhost/alibrohimi/tagihan.php">
                  <span data-feather="calendar"></span>
                  Tagihan
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link " href="http://localhost/alibrohimi/pengaturan-administrator.php">
                  <span data-feather="cloud"></span>
                  Pengaturan
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link " href="http://localhost/alibrohimi/pemeliharaan-administrator.php">
                  <span data-feather="database"></span>
                  Pemeliharaan
                </a>
              </li>
            </ul>            
          </div>
        </nav>

        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
              <h6 class="h6">Kelulusan</h6>
            </div>
            <div>
              <button type="button" class="btn btn-primary">Add Data Siswa</button>              
            </div>
            <p></p>
            <div class="alert alert-primary" role="alert">
              <b>Fitur Kelulusan digunakan untuk mengubah status siswa jika sudah lulus, </b>
              <p></p>
              <p>ada tiga status untuk siswa </p>
              <p>1. aktif (Siswa yg masih sekola)</p>
              <p>2. tidak aktif (Siswa yang dikeluarkan atau pindah sekolah</p>
              <p>3. lulus (siswa sudah lulus sekolah</p>
            </div>

            <div class="row">           
              <div class="">
              <!-- <h6>Tampilan Data Siswa Setelah Di search</h6>  -->
              
            </div>
            </div> 
        </main>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="../../assets/js/vendor/popper.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>

    <!-- Icons -->
    <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
    <script>
      feather.replace()
    </script>

    <!-- Graphs -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js"></script>
    <script>
      var ctx = document.getElementById("myChart");
      var myChart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
          datasets: [{
            data: [15339, 21345, 18483, 24003, 23489, 24092, 12034],
            lineTension: 0,
            backgroundColor: 'transparent',
            borderColor: '#007bff',
            borderWidth: 4,
            pointBackgroundColor: '#007bff'
          }]
        },
        options: {
          scales: {
            yAxes: [{
              ticks: {
                beginAtZero: false
              }
            }]
          },
          legend: {
            display: false,
          }
        }
      });
    </script>
  </body>
</html>
