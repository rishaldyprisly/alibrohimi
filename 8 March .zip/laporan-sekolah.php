
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>Beranda keuangan</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="assets/bootstrap/dashboard.css" rel="stylesheet">
  </head>

  <body>
    <nav class="navbar navbar-dark fixed-top bg-success flex-md-nowrap p-0 shadow">
      <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="http://localhost/alibrohimi/login-keuangan.php">Al-Ibrohimi</a>
      
    </nav>

    <div class="container-fluid">
      <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link " href="http://localhost/alibrohimi/beranda-kepala-sekolah.php">
                  <span data-feather="home"></span>
                  Beranda 
                </a>
              </li>
              <!-- <li class="nav-item">
                <a class="nav-link " href="http://localhost/alibrohimi/pembayaran-admin.php">
                  <span data-feather="file"></span>
                  Pembayaran
                </a>
              </li> -->
              
              <li class="nav-item">
                <a class="nav-link active" href="http://localhost/alibrohimi/laporan-sekolah.php">
                  <span data-feather="layers"></span>
                  Laporan <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link " href="http://localhost/alibrohimi/rekap-transaksi-sekolah.php">
                  <span data-feather="layers"></span>
                  Rekapan <span class="sr-only">(current)</span>
                </a>
              </li>
            </ul>            
          </div>
        </nav>

        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
             <!-- <div class="row">
                <div class="col-10">
                  <h6>Belum dilaporkan</h6>
                </div>
               
                  <div class="btn-group">
                      <button class="btn btn-info btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Filter berdasarkan Jenis
                      </button>
                      <div class="dropdown-menu">
                        ...
                      </div>
                  </div>
               </div>  -->
              <div class="table-responsive">
                <!-- <table class="table table-striped table-sm">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>tanggal</th>
                      <th>Nama Transaksi</th>
                      <th>Nama Siswa</th>
                      <th>kelas</th>
                      <th>Jenis</th>
                      <th>Biaya</th>
                      <th>admin</th>
                      <th>aksi</th>
                      <th>laporkan</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>1,001</td>
                      <td>30 juli 2018</td>
                      <th></th>
                      <td>muhammad agus rosidi</td>
                      <td>XII IIS 2</tD>
                      <td>Sekolah</td>  
                      <td>Rp. 500.000</td>
                      <td>M Rozik</td>
                      <th>detail</th>
                      <td><input type="checkbox" aria-label="Checkbox for following text input"  class="float-right"></td>
                    </tr>
                    <tr>
                      <td>1,002</td>
                      <td>30 juli 2018</td>
                      <th></th>
                      <td>budi wijaya</td>
                      <td>XII IIS 2</tD>
                      <td>Sekolah</td>
                      <td>Rp. 900.000</td>
                      <td>M Rozik</td>
                      <th>detail</th>
                      <td><input type="checkbox" aria-label="Checkbox for following text input"  class="float-right"></td>
                    </tr>
                    <tr>
                      <td>1,003</td>
                      <td>30 juli 2018</td>
                      <th></th>
                      <td>muhammad afif</td>
                      <td>XII IIS 2</td>
                      <td>Sekolah</td>
                      <td>Rp. 700.000</td>
                      <td>M Rozik</td>
                      <th>detail</th>
                      <td><input type="checkbox" aria-label="Checkbox for following text input"  class="float-right"></td>
                    </tr>
                    <tr>
                      <td>1,003</td>
                      <td>30 juli 2018</td>
                      <th></th>
                      <td>ahmad syahril</td>
                      <td>XII IIS 2</tD>
                      <td>Madin</td>
                      <td>Rp. 100.000</td>
                      <td>M Rozik</td>
                      <th>detail</th>
                      <td><input type="checkbox" aria-label="Checkbox for following text input"  class="float-right"></td>
                    </tr>
                    <tr>
                      <td>1,004</td>
                      <td>30 juli 2018</td>
                      <th></th>
                      <td>rudi kurniawan</td>
                      <td>XII IIS 2</tD>
                      <td>Madin</td>
                      <td>Rp. 100.000</td>
                      <td>M Rozik</td>
                      <th>detail</th>
                      <td><input type="checkbox" aria-label="Checkbox for following text input"  class="float-right"></td>
                    </tr>
                    <tr>
                      <td>1,005</td>
                      <td>30 juli 2018</td>
                      <th></th>
                      <td>lukman hakim</td>
                      <td>XII IIS 2</tD>
                      <td>Madin</td>
                      <td>Rp. 100.000</td>
                      <td>M Rozik</td>
                      <th>detail</th>
                      <td><input type="checkbox" aria-label="Checkbox for following text input"  class="float-right"></td>
                    </tr>
                    <tr>
                      <td>1,006</td>
                      <td>30 juli 2018</td>
                      <th></th>
                     <td>abdulloh fatah</td>
                      <td>XII IIS 2</tD>
                      <td>Pondok</td>  
                      <td>Rp. 100.000</td>
                      <td>M Rozik</td>
                      <th>detail</th>
                      <td><input type="checkbox" aria-label="Checkbox for following text input"  class="float-right"></td>
                    </tr>
                    <tr>
                      <td>1,007</td>
                      <td>30 juli 2018</td>
                      <th></th>
                     <td>abdulloh fatih</td>
                      <td>XII IIS 2</tD>
                        <td>Pondok</td> 
                      <td>Rp. 100.000</td>
                      <td>M Rozik</td>
                      <th>detail</th>
                      <td><input type="checkbox" aria-label="Checkbox for following text input"  class="float-right"></td>
                    </tr>
                    <tr>
                      <td>1,008</td>
                      <td>30 juli 2018</td>
                      <th></th>
                      <td>ahmad zahid</td>
                      <td>XII IIS 2</tD>
                      <td>Pondok</td>   
                      <td>Rp. 100.000</td>
                      <td>M Rozik</td>
                      <th>detail</th>
                      <td><input type="checkbox" aria-label="Checkbox for following text input"  class="float-right"></td>
                    </tr>
                    <tr>
                      <td>1,009</td>
                      <td>30 juli 2018</td>
                      <th></th>
                      <td>zainul abidin</td>
                      <td>XII IIS 2</tD>
                      <td>Pondok</td>   
                      <td>Rp. 100.000</td>
                      <td>M Rozik</td>
                      <th>detail</th>
                      <td><input type="checkbox" aria-label="Checkbox for following text input"  class="float-right"></td>
                    </tr>
                    <tr>
                      <td>10101</td>
                      <td>30 juli 2018</td>
                      <th></th>
                      <td>nur kholis</td>
                      <td>XII IIS 2</tD>
                      <td>Pondok</td>   
                      <td>Rp. 100.000</td>
                      <td>M Rozik</td>
                      <th>detail</th>
                      <td><input type="checkbox" aria-label="Checkbox for following text input"  class="float-right"></td>
                    </tr>             
                  </tbody>
                  <tfoot>
                    <tr>
                      <th></th>
                      <th><B>TOTAL</B></th>
                      <th></th>
                      <th> Rp. 0</th>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>                      
                      <th><button type="button" class="btn btn-danger">Laporkan</button></th>
                    </tr>
                  </tfoot>
                </table> -->

                  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                   <h4 class="h4">Laporan Transaksi Sekolah</h4>
                    <div class="btn-toolbar mb-2 mb-md-0">
                      <button class="btn btn-sm btn-outline-secondary dropdown-toggle">
                        <span data-feather="calendar"></span>
                        filter berdasarkan petugas (STAFF TU)
                      </button>
                     </div>
                  </div>   
                  <div class="table-responsive">
                <table class="table table-striped table-sm">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>tanggal</th>
                      <th>Transaksi</th>
                      <th>Nama siswa</th>
                      <th>kelas</th>
                      <th>Biaya</th>
                      <th>admin</th>
                      
                      <th>Setujui</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>1,001</td>
                      <td>30 juli 2018</td>
                      <th></th>
                      <td>muhammad agus rosidi</td>
                      <td>XII IIS 2</td>
                      
                      <td>Rp. 500.000</td>
                      <td>M Rozik</td>
                      <th><input type="checkbox" aria-label="Checkbox for following text input"  class="float-right"></th>
                      <th></th>
                      
                      
                      
                    </tr>
                    <tr>
                      <td>1,002</td>
                      <td>30 juli 2018</td>
                      <th></th>
                      <td>budi wijaya</td>
                      <td>XII IIS 2</tD>
                      
                      <td>Rp. 900.000</td>
                      <td>M Rozik</td>
                      <th><input type="checkbox" aria-label="Checkbox for following text input"  class="float-right"></th>
                      <th></th>
                      
                      
                      
                    </tr>
                    <tr>
                      <td>1,003</td>
                      <td>30 juli 2018</td>
                      <th></th>
                      <td>muhammad afif</td>
                      <td>XII IIS 2</tD>
                      
                      <td>Rp. 700.000</td>
                      <td>M Rozik</td>
                      <th><input type="checkbox" aria-label="Checkbox for following text input"  class="float-right"></th>
                      <th></th>
                      
                      
                      
                    </tr>
                    <tr>
                      <td>1,003</td>
                      <td>30 juli 2018</td>
                      <th></th>
                      <td>ahmad syahril</td>
                      <td>XII IIS 2</tD>
                      
                      <td>Rp. 100.000</td>
                      <td>M Rozik</td>
                      <th><input type="checkbox" aria-label="Checkbox for following text input"  class="float-right"></th>
                      <th></th>
                      
                      
                      
                    </tr>
                    <tr>
                      <td>1,004</td>
                      <td>30 juli 2018</td>
                      <th></th>
                      <td>rudi kurniawan</td>
                      <td>XII IIS 2</tD>
                      
                      <td>Rp. 100.000</td>
                      <td>M Rozik</td>
                      <th><input type="checkbox" aria-label="Checkbox for following text input"  class="float-right"></th>
                      <th></th>
                      
                      
                      
                    </tr>
                    <tr>
                      <td>1,005</td>
                      <td>30 juli 2018</td>
                      <th></th>
                      <td>lukman hakim</td>
                      <td>XII IIS 2</tD>
                      
                      <td>Rp. 100.000</td>
                      <td>M Rozik</td>
                      <th><input type="checkbox" aria-label="Checkbox for following text input"  class="float-right"></th>
                      <th></th>
                      
                      
                      
                    </tr>
                    <tr>
                      <td>1,006</td>
                      <td>30 juli 2018</td>
                      <th></th>
                     <td>abdulloh fatah</td>
                      <td>XII IIS 2</tD>
                      
                      <td>Rp. 100.000</td>
                      <td>M Rozik</td>
                      <th><input type="checkbox" aria-label="Checkbox for following text input"  class="float-right"></th>
                      <th></th>
                      
                      
                      
                    </tr>
                    <tr>
                      <td>1,007</td>
                      <td>30 juli 2018</td>
                      <th></th>
                     <td>abdulloh fatih</td>
                      <td>XII IIS 2</tD>
                      
                      <td>Rp. 100.000</td>
                      <td>M Rozik</td>
                      <th><input type="checkbox" aria-label="Checkbox for following text input"  class="float-right"></th>
                      <th></th>
                      
                      
                      
                    </tr>
                    <tr>
                      <td>1,008</td>
                      <td>30 juli 2018</td>
                      <th></th>
                      <td>ahmad zahid</td>
                      <td>XII IIS 2</tD>
                      
                      <td>Rp. 100.000</td>
                      <td>M Rozik</td>
                      <th><input type="checkbox" aria-label="Checkbox for following text input"  class="float-right"></th>
                      <th></th>
                      
                      
                      
                    </tr>
                    <tr>
                      <td>1,009</td>
                      <td>30 juli 2018</td>
                      <th></th>
                      <td>zainul abidin</td>
                      <td>XII IIS 2</tD>
                      
                      <td>Rp. 100.000</td>
                      <td>M Rozik</td>
                      <th><input type="checkbox" aria-label="Checkbox for following text input"  class="float-right"></th>
                      <th></th>
                      
                      
                      
                    </tr>
                    <tr>
                      <td>10101</td>
                      <td>30 juli 2018</td>
                      <th></th>
                      <td>nur kholis</td>
                      <td>XII IIS 2</tD>
                      
                      <td>Rp. 100.000</td>
                      <td>M Rozik</td>
                      <th><input type="checkbox" aria-label="Checkbox for following text input"  class="float-right"></th>
                      <th></th>
                      
                      
                      
                    </tr>             
                  </tbody>
                  <tfoot>
                    <tr>
                      <th></th>
                      <th><B>TOTAL</B></th>
                      <th></th>
                      <th> Rp. 0</th>
                      <th></th>
                      <th></th>
                      <th></th>                   
                      <th><button type="button" class="btn btn-success">Terima Laporan</button></th>
                    </tr>
                  </tfoot>          
                </table>  


              </div>
        </main>

      </div>
    </div>

    
          
    
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="../../assets/js/vendor/popper.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>

    <!-- Icons -->
    <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
    <script>
      feather.replace()
    </script>

    
  </body>
</html>
