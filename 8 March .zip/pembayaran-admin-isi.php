
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>Beranda keuangan</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="assets/bootstrap/dashboard.css" rel="stylesheet">

  </head>

  <body>
    <nav class="navbar navbar-dark fixed-top bg-success flex-md-nowrap p-0 shadow">
      <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="http://localhost/alibrohimi/login-keuangan.php">Al-Ibrohimi</a>
      <input class="form-control form-control-dark w-100" type="text" placeholder="Masukan NIP" aria-label="Search">
      <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap">
          <a class="nav-link" href="#">Cari</a>
        </li>
      </ul>
    </nav>

    <div class="container-fluid">
      <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link " href="http://localhost/alibrohimi/beranda-admin-keu.php">
                  <span data-feather="home"></span>
                  Beranda 
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="http://localhost/alibrohimi/pembayaran-admin.php">
                  <span data-feather="file"></span>
                  Pembayaran <span class="sr-only">(current)</span>
                </a>
              </li>
              
              <li class="nav-item">
                <a class="nav-link" href="http://localhost/alibrohimi/laporan-admin-keu.php">
                  <span data-feather="layers"></span>
                  Laporan
                </a>
              </li>
            </ul>            
          </div>
        </nav>

        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            
          </div>

          <div class="alert alert-primary" role="alert">
            <div class="row">    
                <div class="col-lg-6">       
                  <div class="row">
                    <label class="col-sm-2 col-form-label">NIP :</label>
                    <div class="col-sm-10">
                      <label class="col-sm-5 col-form-label"><b>121111062</b></label>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label">Nama :</label>
                    <div class="col-sm-10">
                      <label class="col-sm-10 col-form-label"><b>Muhammad Agus Rosidi</b></label>
                    </div>
                  </div>
                </div> 
                <div class="col-lg-6"> 
                  <div class="row">
                    <label class="col-sm-2 col-form-label">Kelas :</label>
                    <div class="col-sm-10">
                      <label class="col-sm-5 col-form-label"><b>X MIPA 1</b></label>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label">Alamat :</label>
                    <div class="col-sm-10">
                      <label class="col-sm-5 col-form-label"><b>Leran Manyar Gresik</b></label>
                    </div>
                  </div>
                </div>     
            </div>             
          </div>  

          <div class="row">
          
          <div class="col-lg-6">
          <h5>Sudah Dibayar</h5>
          <div class="table-responsive">                    
            <table class="table table-striped table-sm">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Keterangan</th>
                  <th>Tahun</th>
                  <th>Jenis</th>
                  <th>Biaya</th>
                  <th>cetak</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>1,001</td>
                  <td>sahriyah januari madin</td>
                  <td>2018</td>
                  <td>pondok</td>
                  <td>Rp. 100.000</td>
                  <td><input type="checkbox" aria-label="Checkbox for following text input"></td>
                </tr>
                <tr>
                  <td>1,002</td>
                  <td>sahriyah februari madin</td>
                  <td>2018</td>
                  <td>pondok</td>
                  <td>Rp. 100.000</td>
                  <td><input type="checkbox" aria-label="Checkbox for following text input"></td>
                </tr>
                <tr>
                  <td>1,003</td>
                  <td>sahriyah maret</td>
                  <td>2018</td>
                  <td>pondok</td>
                  <td>Rp. 100.000</td>
                  <td><input type="checkbox" aria-label="Checkbox for following text input"></td>
                </tr>
                <tr>
                  <td>1,003</td>
                  <td>sahriyah april</td>
                  <td>2018</td>
                  <td>madin</td>
                  <td>Rp. 100.000</td>
                  <td><input type="checkbox" aria-label="Checkbox for following text input"></td>
                </tr>
                <tr>
                  <td>1,004</td>
                  <td>sahriyah mei</td>
                  <td>2018</td>
                  <td>madin</td>
                  <td>Rp. 100.000</td>
                  <td><input type="checkbox" aria-label="Checkbox for following text input"></td>
                </tr>
                <tr>
                  <td>1,005</td>
                  <td>sahriyah juni</td>
                  <td>2018</td>
                  <td>sekolah</td>
                  <td>Rp. 100.000</td>
                  <td><input type="checkbox" aria-label="Checkbox for following text input"></td>
                </tr>
                <tr>
                  <td>1,006</td>
                 <td>sahriyah juli</td>
                  <td>2018</td>
                  <td>sekolah</td>
                  <td>Rp. 100.000</td>
                  <td><input type="checkbox" aria-label="Checkbox for following text input"></td>
                </tr>
                <tr>
                  <td>1,007</td>
                 <td>her registrasi</td>
                  <td>2018</td>
                  <td>sekolah</td>
                  <td>Rp. 100.000</td>
                  <td><input type="checkbox" aria-label="Checkbox for following text input"></td>
                </tr>
                <tr>
                  <td>1,008</td>
                  <td>ujian semester 1</td>
                  <td>2018</td>
                  <td>sekolah</td>
                  <td>Rp. 100.000</td>
                  <td><input type="checkbox" aria-label="Checkbox for following text input"></td>
                </tr>
                <tr>
                  <td>1,009</td>
                  <td>komputer</td>
                  <td>2018</td>
                  <td>sekolah</td>
                  <td>Rp. 100.000</td>
                  <td><input type="checkbox" aria-label="Checkbox for following text input"></td>
                </tr>
                <tr>
                  <td>10101</td>
                  <td>osis</td>
                  <td>2018</td>
                  <td>sekolah</td>
                  <td>Rp. 100.000</td>
                  <td><input type="checkbox" aria-label="Checkbox for following text input"></td>
                </tr>             
              </tbody>

              <tfoot>
                <tr>
                  <th></th>
                  <th><B>TOTAL</B></th>
                  <th></th>
                  <th> Rp. 13.000.000</th>
                  <th></th>
                  <th>
                    <div class="bd-example">
                      <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#exampleModalLive">
                        Cetak
                      </button>
                    </div>
                  </th>
                </tr>
              </tfoot>              
            </table>
          </div>
          </div>
          
          <div class="col-lg-6">
          <h5>Belum Di Bayar</h5>
          <div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>keterangan</th>
                  <th>tahun</th>
                  <th>Jenis</th>
                  <th>biaya</th>
                  
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>101</td>
                  <td>sahriyah agustus madin semester 1 pondok</td>
                  <td>2018</td>
                  <td>Rp. 100.000</td>
                  <td><input type="checkbox" aria-label="Checkbox for following text input"></td>
                </tr>
                <tr>
                  <td>102</td>
                  <td>sahriyah september</td>
                  <td>2018</td>
                  <td>Rp. 100.000</td>
                  <td><input type="checkbox" aria-label="Checkbox for following text input"></td>
                  
                </tr>
                <tr>
                  <td>103</td>
                  <td>sahriyah oktober</td>
                  <td>2018</td>
                  <td>Rp. 100.000</td>
                  <td><input type="checkbox" aria-label="Checkbox for following text input"></td>
                </tr>
                <tr>
                  <td>104</td>
                  <td>sahriyah november</td>
                  <td>2018</td>
                  <td>Rp. 100.000</td>
                  <td><input type="checkbox" aria-label="Checkbox for following text input"></td>
                </tr>
                <tr>
                  <td>105</td>
                  <td>sahriyah desember</td>
                  <td>2018</td>
                  <td>Rp. 100.000</td>
                  <td><input type="checkbox" aria-label="Checkbox for following text input"></td>
                </tr>
                <tr>
                  <td>106</td>
                  <td>sahriyah januari</td>
                  <td>2019</td>
                  <td>Rp. 100.000</td>
                  <td><input type="checkbox" aria-label="Checkbox for following text input"></td>
                </tr>
                <tr>
                  <td>107</td>
                  <td>sahriyah februari</td>
                  <td>2019</td>
                  <td>Rp. 100.000</td>
                  <td><input type="checkbox" aria-label="Checkbox for following text input"></td>
                </tr>
                <tr>
                  <td>108</td>
                  <td>sahriyah maret</td>
                  <td>2019</td>
                  <td>Rp. 100.000</td>
                  <td><input type="checkbox" aria-label="Checkbox for following text input"></td>
                </tr>
                <tr>
                  <td>109</td>
                  <td>sahriyah april</td>
                  <td>2019</td>
                  <td>Rp. 100.000</td>
                  <td><input type="checkbox" aria-label="Checkbox for following text input"></td>
                </tr>
                <tr>
                  <td>110</td>
                  <td>sahriyah mei</td>
                  <td>2019</td>
                  <td>Rp. 100.000</td>
                  <td><input type="checkbox" aria-label="Checkbox for following text input"></td>
                </tr>
                <tr>
                  <td>111</td>
                  <td>sahriyah juni</td>
                  <td>2019</td>
                  <td>Rp. 100.000</td>
                  <td><input type="checkbox" aria-label="Checkbox for following text input"></td>
                </tr>               
                <tfoot>
                <tr>
                  <th></th>
                  <th><B>TOTAL</B></th>
                  <th></th>
                  <th> Rp. 0</th>
                  <th></th>                  
                </tr>
                <tr>
                  <th></th>
                  <th>
                    <div class="input-group input-group-sm mb-3">
                      <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroup-sizing-sm">Kode petugas</span>
                      </div>
                      <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm">
                    </div>
                  </th>
                  <th>
                    <div id="exampleModalLive" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="exampleModalLiveLabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLiveLabel">Cetak Kwitansi</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
                            <p>Apakah anda yakin...?</p>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary">Cetak</button>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div class="bd-example">
                      <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalLive">
                        Bayar
                      </button>
                    </div>
                  </th>
                  <th>                    
                  </th>
                </tr>
              </tfoot>                
              </tbody>


            </table>
          </div>
          </div>          
        </main>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
    <script>window.jQuery || document.write('<script src="assets/bootstrap/jquery-3.3.1.slim.min.js"><\/script>')</script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>

    <!-- Icons -->
    <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
    <script>
      feather.replace()
    </script>

    
  </body>
</html>
