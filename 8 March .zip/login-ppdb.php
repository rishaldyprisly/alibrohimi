
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>Signin Template for Bootstrap</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="assets/bootstrap/signin.css" rel="stylesheet">
  </head>

  <body class="text-center">
    <form class="form-signin">
      <img class="mb-4" src="assets/bootstrap/ma-aly.png" alt="" width="72" height="102">
      <h1 class="h3 mb-3 font-weight-normal">PPDB <b>Al-Ibrohimi</b></h1>
      <label for="inputEmail" class="sr-only">username</label>
      <input type="text" id="inputEmail" class="form-control text-center" placeholder=" username" required autofocus>
      <label for="inputPassword" class="sr-only">Password</label>
      <input type="password" id="inputPassword" class="form-control text-center" placeholder=" Password" required>
      <div class="checkbox mb-3">        
      </div>      
      <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
      <a href="http://localhost/alibrohimi/beranda-admin-ppdb.php">next</a>
      <a href="http://localhost/alibrohimi/form-pendaftaran.php">txen</a>
      <p class="mt-5 mb-3 text-muted">&copy; ICT Pondok Pesantren Al-Ibrohimi 2018</p>
    </form>
  </body>
</html>
